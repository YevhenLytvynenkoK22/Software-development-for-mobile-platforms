package com.example.practice1;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Picture;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new DrawView(this));
        this.setTitle("Practice 1");
    }

    public void Next() {

    }

    class DrawView extends View {
        Paint p;

        public DrawView(Context context) {
            super(context);
            p = new Paint();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            int cx = canvas.getWidth() / 2;
            int cy = canvas.getHeight() / 2;

            p.setARGB(255, 220, 180, 140);
            canvas.drawCircle(cx, cy, 150, p);

            p.setARGB(255, 220, 180, 140);
            canvas.drawPath(makeTriangle(cx - 100, cy - 100, cx - 150, cy - 200, cx - 40, cy - 170), p);
            canvas.drawPath(makeTriangle(cx + 100, cy - 100, cx + 150, cy - 200, cx + 40, cy - 170), p);

            p.setARGB(255, 0, 0, 0);
            canvas.drawCircle(cx - 50, cy - 20, 20, p);
            canvas.drawCircle(cx + 50, cy - 20, 20, p);

            p.setARGB(255, 255, 100, 100);
            canvas.drawCircle(cx, cy + 30, 15, p);

            p.setARGB(255, 0, 0, 0);
            canvas.drawArc(cx - 20, cy + 30, cx + 20, cy + 70, 0, 180, false, p);

            canvas.drawLine(cx - 150, cy + 20, cx - 50, cy + 20, p);
            canvas.drawLine(cx - 150, cy + 40, cx - 50, cy + 30, p);
            canvas.drawLine(cx - 150, cy, cx - 50, cy + 10, p);

            canvas.drawLine(cx + 50, cy + 20, cx + 150, cy + 20, p);
            canvas.drawLine(cx + 50, cy + 30, cx + 150, cy + 40, p);
            canvas.drawLine(cx + 50, cy + 10, cx + 150, cy, p);
        }

        private android.graphics.Path makeTriangle(float x1, float y1, float x2, float y2, float x3, float y3) {
            android.graphics.Path path = new android.graphics.Path();
            path.moveTo(x1, y1);
            path.lineTo(x2, y2);
            path.lineTo(x3, y3);
            path.close();
            return path;
        }


    }
}